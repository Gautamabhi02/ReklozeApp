class Env
{
       static const String baseUrl =  'https://localhost:44318/api';
       //  static const String baseUrl = 'https://golu001-001-site1.qtempurl.com/api';
}